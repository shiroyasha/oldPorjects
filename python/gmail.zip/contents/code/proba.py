# -*- coding: utf-8 -*-
import imaplib, re

conn = imaplib.IMAP4_SSL("imap.gmail.com", 993)
conn.login("igisar", "x3i2u51n4")
unreadCount = re.search("UNSEEN (\d+)", conn.status("INBOX", "(UNSEEN)")[1][0]).group(1)

print unreadCount